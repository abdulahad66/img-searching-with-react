import './App.css';
import './page.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [photo, setPhoto] = useState('');
  const [result, setResult] = useState([]);
  const [page, setPage] = useState(1);
  const [theme, setTheme] = useState('light');
  const [isHeaderActive, setHeaderActive] = useState(false);


  useEffect(() => {
    getPhotoHandler();
  }, [page]);

  const handlepagechange = () => {
    setPage(page+1)
  };
  const handlepagecprevious = () => {
    setPage(page-1)
  };

  const handleToggle = () => {
    setHeaderActive(!isHeaderActive);
  };

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 991) {
        setHeaderActive(false);
      }
    };

    // Initial check on component mount
    handleResize();

    // Event listener for window resize
    window.addEventListener('resize', handleResize);

    // Cleanup event listener on component unmount
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []); // Empty dependency array ensures the effect runs only once on mount





  // Dark and light theme
  useEffect(() => {
    const currentTheme = localStorage.getItem('theme');
    if (currentTheme) {
      setTheme(currentTheme);
    }
  }, []);

  const switchTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
  };

  // Input Box Value handler Start
  function inputValueChangeHandler(e) {
    console.log(e.target.value); //Check Input Box Value insert or not
    setPhoto(e.target.value);
  }

  // Button Click Get photo handler Start
  const getPhotoHandler = () => {
    axios
      .get(
        `https://api.unsplash.com/search/photos?page=${page}&query=${photo}&client_id=ic69EAEYxlmpQ5xO4rlogtyx7cklGbyHoFD3e8MP65Q`
      )
      .then((response) => {
        console.log(response.data);
        setResult(response.data.results);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  };





  return (
    <>

      <header id="site-header"  className= "w3l-header-4 main-header fixed-top {isHeaderActive ? 'active' : ''}">
        <div className="container w3HeaderLogoEd">
          <nav className="navbar navbar-expand-lg stroke">
            <h1><a className="navbar-brand" href="#">
              Photo<span className="sub-spl">f</span>lash </a></h1>

            <button className="navbar-toggler collapsed bg-gradient" type="button" data-toggle="collapse"
              data-target="#navbar-content" aria-controls="navbar-content" aria-expanded="false"
              aria-label="Toggle Navigation" onClick={handleToggle}>
              <span className="navbar-toggler-icon fa icon-expand fa-bars"></span>
              <span className="navbar-toggler-icon fa icon-close fa-times"></span>
            </button>

            {/* <div className="collapse navbar-collapse" id="navbar-content"> */}
            <div id="navbar-content" className="collapse navbar-collapse" style={{ display: isHeaderActive ? 'block' : 'none' }}>
              <ul id="primary-menu" className="navbar-nav mx-lg-auto">
                <li id="menu-item-12"
                  className="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-9 current_page_item menu-item-12 nav-item active">
                  <a href="#" className="nav-link active">Home</a></li>
                <li id="menu-item-29"
                  className="menu-item menu-item-type-post_type menu-item-object-page menu-item-29 nav-item"><a
                    href="#" className="nav-link">About</a></li>
                <li id="menu-item-28"
                  className="menu-item menu-item-type-post_type menu-item-object-page menu-item-28 nav-item"><a
                    href="#" className="nav-link">Services</a></li>

                <li id="menu-item-28"
                  className="menu-item menu-item-type-post_type menu-item-object-page menu-item-28 nav-item"><a
                    href="#" className="nav-link">Blog</a></li>

                <li id="menu-item-26"
                  className="menu-item menu-item-type-post_type menu-item-object-page menu-item-26 nav-item"><a
                    href="#" className="nav-link">Contact</a></li>
              </ul>
              <ul className="navbar-nav search-right mt-lg-0 mt-2">
                <li className="nav-item mr-3 HeaderSearch" title="Search">
                  <a href="#search" className="btn search-search">
                    <span className="fa fa-search" aria-hidden="true"></span>
                  </a>

                </li>

                <li className="nav-item HeaderButton">
                  <a href="#url" className="btn download d-none d-lg-block btn-style">Download</a>
                </li>

              </ul>
            </div>


            <div className="mobile-position DarkandLight">
              <nav className="navigation">
                <div className="theme-switch-wrapper">
                  <label className="theme-switch" htmlFor="checkbox">
                    {/* <input type="checkbox" id="checkbox"/> */}
                    <input
                      type="checkbox" id="checkbox"
                      checked={theme === 'dark'}
                      onChange={switchTheme}
                    />
                    <div className="mode-container">
                      <i className="gg-sun"></i>
                      <i className="gg-moon"></i>
                    </div>
                  </label>
                </div>
              </nav>


            </div>
          </nav>
        </div>
      </header>
      <div className="header-fixed-space-height">

      </div>

      <section className="bannerhny w3pvt-banner" id="home">

        <div className="container HomePageHeroHeader">
          <div className="banner-info text-center mx-auto">
            <div className="w3pvt-logo align-self">
              <span className="fa fa-camera" aria-hidden="true"></span>
              <h3>Make The World A Better Place With Photo.</h3>

              <span className="d-flex span">


                <input type="search" className="htmlForm-control" placeholder="Search.." value={photo} onChange={inputValueChangeHandler}
                />
                <button type="submit" className="btn" onClick={getPhotoHandler}>
                  {/* Search Images */}
                  <span className="fa fa-search" aria-hidden="true"></span>
                </button>

              </span>

            </div>
          </div>
        </div>
      </section>

      <section className="w3-gallery py-5">
        <div className="container py-md-5 HomePageGallery">

         

          <div className="container portfolio-area">
            <div className="row">
              <div className="col-lg-12 col-md-12 row">
                {result.map((value, index) => {
                  return (
                    <div  className="col-md-3 col-lg-3">
                      <div key={index} className="img-section">

                      <img
                        className="img-fluid"
                        src={value.urls.small}
                        alt="Card image cap"
                      />
                    </div>
                    </div>
                  );
                })}
              </div>
             <div className="Paginationbtn mt-4">
              <button className="btn download" onClick={handlepagecprevious}>Previous Page</button>
             <button className="btn download" onClick={handlepagechange}>Next Page</button>
               </div>
              
            </div>
          </div>
          

        </div>

      </section>


      <section className="w3l-footer">
    <footer className="footer-28 pt-5">

      <div className="container pt-lg-3 text-justify">

        <div className="w3l-forms-9 px-4 FooterSubscribe" id="newsletter">
          <div className="main-w3 py-4">
            <div className="container-fluid py-lg-3 py-2">
              <div className="row align-items-center">
                <div className="main-midd col-lg-6">
                  <h4 className="title-head">
                    Subscribe our newsletter </h4>
                  <p>We’re a team of non-cynics who truly care for our work.</p>
                </div>
                <div className="main-midd-2 col-lg-6 mt-lg-0 mt-4">

                  <form action="#" method="POST" className="rightside-form">

                    <input type="email" className="form-control" name="Email" placeholder="Enter your email"/>

                    <button className="btn" type="submit">Subscribe</button>

                  </form>

                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row footer-top-28 PhotoflashFooter">
          <div className="col-lg-6 footer-list-28 pr-lg-5 mt-5">
            <h6 className="footer-title-28">
              Photo<span className="sub-spl">f</span>lash</h6>

              
            <p className="pr-lg-5">There's Only One Thing In The World I Want And That Is Photo.</p>

            <div className="main-social-footer-28 mt-3 FooterSocial">
              <ul className="social-icons">

                <li className="facebook">
                  <a href="#" title="Facebook">
                    <span className="fa-brands fa-facebook-f" aria-hidden="true"></span>
                    
                  </a>
                </li>

                <li className="twitter">
                  <a href="#" title="Twitter">
                    <span className="fa-brands fa-twitter" aria-hidden="true"></span>
                   
                  </a>
                </li>

                <li className="dribbble">
                  <a href="#" title="Dribbble">
                    <span className="fa-brands fa-dribbble" aria-hidden="true"></span>
                   
                  </a>
                </li>

                <li className="google">
                  <a href="#" title="Google">
                    <span className="fa-brands fa-google" aria-hidden="true"></span>
                    
                  </a>
                </li>

              </ul>
            </div>

          </div>

          <div className="col-lg-6">
            <div className="row">

              <div className="col-md-4 col-6 footer-list-28 mt-5">
                <div id="archives-4" className="widget_archive">
                  <h6 className="footer-title-28">Archives</h6>
                  <ul>
                    <li><a href='#'>Feburary 2024</a></li>
                    <li><a href='#'>March 2024</a></li>
                    <li><a href='#'>April 2024</a></li>
                  </ul>

                </div>
              </div>

              <div className="col-md-4 col-6 footer-list-28 mt-5">
                <div id="categories-4" className="widget_categories">
                  <h6 className="footer-title-28">More</h6>
                  <ul>
                    <li className="cat-item cat-item-3"><a href="#">Home</a>
                    </li>
                    <li className="cat-item cat-item-4"><a href="#">About</a>
                    </li>
                    <li className="cat-item cat-item-5"><a href="#">Services</a>
                    </li>
                    <li className="cat-item cat-item-6"><a href="#">Contact</a>
                    </li>
                  </ul>

                </div>
              </div>

              <div className="col-md-4 col-6 footer-list-28 mt-5">
                <div id="meta-4" className="widget_meta">
                  <h6 className="footer-title-28">Our Feed</h6>
                  <ul>
                    <li><a href="#">Log in</a></li>
                    <li><a href="#">Entries feed</a></li>
                    <li><a href="#">Comments feed</a></li>
                    <li><a href="#">Photoflash.org</a></li>
                  </ul>

                </div>
              </div>

            </div>
          </div>

        </div>

     
        <div className="midd-footer-28 align-center py-4 mt-5">
          <p className="copy-footer-28 text-center CopyRights"> &copy; 2024 All Rights Reserved And Create by <a
              href="">Abdul Ahad</a>
          </p>
        </div>
    

      </div>



    </footer>


  </section>



    </>
  );
}

export default App;
